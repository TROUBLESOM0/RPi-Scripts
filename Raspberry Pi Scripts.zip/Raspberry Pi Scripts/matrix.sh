#!/bin/bash
# It's The Matrix
perl -e '$|++; while (1) { print " " x (rand(35) + 1), int(rand(2)) }'
